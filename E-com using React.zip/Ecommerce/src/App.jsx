
import { NavLink, Route, Routes } from 'react-router-dom'
import './App.css'
import Home from './Pages/Home'
import Contact from './Pages/Contact'
import Pagenotfound from './Pages/Pagenotfound'
import About from './Pages/About'
import Registration from './Pages/Registration'
import Login from './Pages/Login'
import ExploreMore from './Pages/ExploreMore'
import ExploreSuit from './Pages/ExploreSuit'

function App() {

  return (
    <>

    <div className='header'>
      <NavLink to={"/"}className={"navbar"}>Home</NavLink>
      <NavLink to={"/about"} className={"navbar"}>About</NavLink>
      <NavLink to={"/contact"} className={"navbar"}>Contact</NavLink>
      <input type='text' style={{width:"500px",marginLeft:"100px",marginRight:"50px",height:"30px"}}></input>
      <NavLink to={"/registration"} className={"navbar"}>Registration</NavLink>
      <NavLink to={"/login"} className={"navbar"}>Login</NavLink>
    </div>

   <Routes>
   <Route path='/' element={<Home></Home>}></Route>
   <Route path='/about' element={<About></About>}></Route>
   <Route path='/contact' element={<Contact></Contact>}></Route>
   <Route path='/registration' element={<Registration></Registration>}></Route>
   <Route path='/login' element={<Login></Login>}></Route>
   <Route path='/explore' element={<ExploreMore></ExploreMore>}></Route>
   <Route path='/exploresuit' element={<ExploreSuit></ExploreSuit>}></Route>
   <Route path='*' element={<Pagenotfound></Pagenotfound>}></Route>
   </Routes>
     
    </>
  )
}

export default App
