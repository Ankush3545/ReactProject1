//import React from 'react'

import { useNavigate } from "react-router-dom"

//import { useNavigate } from "react-router-dom"

export default function Home() {
  const navigateSuit=useNavigate()
  const handleSuit=()=>{
    navigateSuit("/exploresuit")

  }
  const navigate=useNavigate();
  const handleButton=()=>{
    //console.log("Button Was Clicked")
    navigate("/explore")
    
  }
  return (
    <>
    <h1 className="heading">Trending Shoes</h1>
    <div className="product-shoes">
      <div className="shoes"> 
        <img src="shoes-1.jpg"></img>
        <h3 className="price">Nike Shoes</h3>
        <h4 className="price">$90</h4>
        <button onClick={handleButton}>Explore More</button>
      </div>
      <div className="shoes"> 
        <img src="shoes-2.jpg"></img>
        <h3 className="price">Sports Running Shoes</h3>
        <h4 className="price">$100</h4>
        <button onClick={handleButton}>Explore More</button>
      </div>
      <div className="shoes"> 
        <img src="shoes-3.jpg"></img>
        <h3 className="price">Fashion Nike</h3>
        <h4 className="price">$90</h4>
        <button onClick={handleButton}>Explore More</button>
      </div>

    </div>
    <h1 className="heading">Trending Suit</h1>
    
    <div className="product-suit">
      <div className="suit">
        <img src="wn4 c.jpg" ></img>
        <h2 className="price">Ladies Suit</h2>
        <h4 className="price">$115</h4>
        <button style={{marginTop:"33px"}} onClick={handleSuit}>Explore More</button>
      </div>

      <div className="suit">
        <img src="wn5 c.jpg"></img>
        <h2 className="price">Fancy Dress</h2>
        <h4 className="price">$215</h4>
        <button  style={{marginTop:"33px"}} onClick={handleSuit}>Explore More</button>
      </div>

      <div className="suit">
        <img src="wn6 c.jpg"></img>
        <h2 className="price">Frok Suit</h2>
        <h4 className="price">$125</h4>
        <button  style={{marginTop:"33px"}} onClick={handleSuit}>Explore More</button>
      </div>

    </div>

    <h1 className="homemoredetail">FOR MORE DETAILS : </h1>
    <div className="homemoredetailparent">
      <div className="homemoredetaildiv">
        <h3 style={{textDecoration:"underline"}}>Get to Know us:</h3>
        <li>About Website</li>
        <li>Press Releases</li>
        <li>Website Service</li>
      </div>
      <div className="homemoredetaildiv">
        <h3 style={{textDecoration:"underline"}}>Connect With us:</h3>
        <li>FaceBook</li>
        <li>Twitter</li>
        <li>Instagram</li>
        <li>LinkedIN</li>
      </div>
      <div className="homemoredetaildiv">
        <h3 style={{textDecoration:"underline"}}>Make Money With Us:</h3>
        <ul>
        <li>Sell on our website</li>
        <li>Protect and build your Brand</li>
        <li>Become an affiliate</li>
        <li>Advertise your product</li>
        </ul>
      </div>
      <div className="homemoredetaildiv">
        <h3 style={{textDecoration:"underline"}}>Let us help:</h3>
        <li>Your Accounts</li>
        <li>Returning Center</li>
        <li>Product Safety Alerts</li>
        <li>100% Purchase Protection</li>
      </div>
    </div>
    
    </>
  )
}
