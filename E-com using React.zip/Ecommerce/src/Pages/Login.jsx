//import React from 'react'

import { useState } from "react"
import { useNavigate } from "react-router-dom"

export default function Login() {
    const navigate=useNavigate()
    const [data,setData]=useState({
        phonenumber:"",
        email:"",
    })

    const handleChange=(e)=>{
        setData({...data,[e.target.name]:e.target.value})

    }
    const handleSubmit=(e)=>{
        if(!data.phonenumber){
            alert("Enter Registered PhoneNumber")
        }
        else if(!data.email){
            alert("Enter Email id to Login")
        }

        else{
                e.preventDefault()
                console.log(data)
                setData({phonenumber:"",email:""})
                navigate("/")
                alert("Welcome to Our Website");
            }
    
    }
  return (
    <>
     <form className="login-form">
        <h2>Login Form</h2>

        <div className="register-div">
        <label htmlFor="">Phone Number</label><br></br>
        <input type="text" style={{width:"55%",height:"25px",fontSize:"20px"}}
         value={data.phonenumber}
         name="phonenumber"
         onChange={handleChange}></input><br></br>

        <label htmlFor="">Email</label><br></br>
        <input type="email" style={{width:"55%",height:"25px",fontSize:"20px"}}
        value={data.email}
        name="email"
        onChange={handleChange}></input><br></br>

       
        <button onClick={handleSubmit}>Login</button>

        </div>
    
    </form>
    </>
  )
}
