//import React from 'react'

import { useState } from "react"
import { useNavigate } from "react-router-dom"


export default function Registration() {
    const navigate=useNavigate()
    const[data,setData]=useState({
        firstname:"",
        lastname:"",
        phonenumber:"",
        email:""
    })

    const handleChange=(e)=>{
        setData({...data,[e.target.name]:e.target.value})
    }

    const handleSubmit=(e)=>{
        if(!data.firstname){
            alert("Enter First Name")
        }
        else if(!data.lastname){
            alert("Enter Last Name")
        }
        else if(!data.phonenumber){
            alert("Enter Phone Number")
        }
        else if(!data.email){
            alert("Enter Email id to register")
        }

            else{
                e.preventDefault()
                console.log(data)
                setData({firstname:"",lastname:"",phonenumber:"",email:""})
               navigate("/login")
               alert("Thank you for Registration on our website")
        
        }
        
    }

  return (
    <>
    <form className="register-form">
        <h2>Registration Form</h2>

        <div className="register-div">
        <label htmlFor="">First Name</label><br></br>
        <input type="text" style={{width:"55%",height:"25px",fontSize:"20px"}}
         value={data.firstname}
         name="firstname"
         onChange={handleChange}></input><br></br>

        <label htmlFor="">Last Name</label><br></br>
        <input type="text" style={{width:"55%",height:"25px",fontSize:"20px"}}
        value={data.lastname}
        name="lastname"
        onChange={handleChange}></input><br></br>

        <label htmlFor="">Phone Number</label><br></br>
        <input type="number" style={{width:"55%",height:"25px",fontSize:"20px"}}
        name="phonenumber"
        value={data.phonenumber}
        onChange={handleChange}></input><br></br>

        <label htmlFor="">Email</label><br></br>
        <input type="email" style={{width:"55%",height:"25px",fontSize:"20px"}}
        name="email"
        value={data.email}
        onChange={handleChange}></input><br></br>

        <button onClick={handleSubmit}>Submit</button>

        </div>
    
    </form>
    </>
  )
}
