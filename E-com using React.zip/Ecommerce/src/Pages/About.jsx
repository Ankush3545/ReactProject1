//import React from 'react'

export default function About() {
  return (
    <>
    <h1 style={{marginLeft:"40%",marginTop:"10px",textDecoration:"underline"}}>ABOUT SHOES</h1>
    <div className="aboutshoes">Shoes are footwear designed to protect and comfort the feet while providing support and style. They come in various types, materials, and designs, serving different purposes such as casual wear, sports, formal occasions, and specialized activities.

Types of Shoes:
Casual Shoes : Sneakers, loafers, sandals, slip-ons

Formal Shoes : Oxfords, brogues, dress shoes

Athletic Shoes : Running shoes, basketball shoes, cleats

Boots : Work boots, hiking boots, Chelsea boots

Specialty Shoes : Dance shoes, orthopedic shoes, safety shoes

Materials Used:
Leather:Durable, breathable, and stylish

Canvas : Lightweight and comfortable

Rubber : Used for soles for traction and flexibility

Synthetic Materials : Cost-effective and water-resistant

Choosing the Right Shoes:
Comfort and fit are crucial to avoid foot pain.

The type of activity determines the best shoe choice (e.g., running shoes for jogging, boots for hiking).

Quality materials ensure durability and long-term use.</div>
<h1 style={{marginTop:"10px",marginLeft:"39%",textDecoration:"underline"}}>ABOUT LADIES SUIT</h1>
<div className="aboutladiessuit">A ladies suit is a stylish and versatile outfit designed for professional, formal, or semi-formal occasions. It typically consists of a blazer and matching trousers, skirts, or dresses. Women’s suits are available in various designs, fabrics, and fits, making them suitable for business, casual, and special events.

Types of Ladies Suits
Pant Suit : A blazer paired with tailored trousers. Ideal for office wear, business meetings, and formal events.

Skirt Suit : A blazer worn with a pencil or A-line skirt. A sophisticated option for corporate settings or elegant occasions.

Three-Piece Suit : Includes a blazer, trousers or skirt, and a matching vest for a polished, layered look.

Tuxedo Suit : A chic alternative for evening wear with sleek tailoring, often featuring satin lapels.

Casual Suit : Relaxed-fit blazers with wide-leg pants or shorts, perfect for smart-casual settings.

Ethnic Suit : Traditional suits like salwar kameez, anarkali, or sharara suits worn in South Asian cultures.

Popular Fabrics
Wool : Warm, breathable, and classic for business suits.

Cotton : Lightweight and comfortable for all-day wear.

Linen : Great for summer, offering a breezy and elegant look.

Velvet : Luxurious and ideal for evening suits.

Synthetic Blends (Polyester, Rayon, Spandex) : Affordable and wrinkle-resistant.</div>
    </>
  )
}
