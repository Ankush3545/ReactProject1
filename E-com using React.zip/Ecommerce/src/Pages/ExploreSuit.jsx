//import React from 'react'

import { useNavigate } from "react-router-dom";

function ExploreSuit() {
    const navigate=useNavigate()
    const handleGoBack=()=>{
        navigate("/")
    }
  return (
    <>
    <div className="para-suit">
        <h1 style={{textAlign:"center",textDecoration:"underline"}}>Ladies Suit</h1>
        <p>
        A suit, also called a lounge suit, business suit, dress suit, or formal
      suit is a set of clothes comprising a suit jacket and trousers of
      identical textiles generally worn with a collared dress shirt, necktie,
      and dress shoes. A skirt suit is similar, but with a matching skirt
      instead of trousers. It is currently considered semi-formal wear or
      business wear in contemporary Western dress codes, however when the suit
      was originally developed it was considered an informal or more casual
      option compared to the prevailing clothing standards of aristocrats and
      businessmen. The lounge suit originated in 19th-century Britain as
      sportswear and British country clothing, which is why it was seen as more
      casual than citywear at that time, with the roots of the suit coming from
      early modern Western Europe formal court or military clothes. After
      replacing the black frock coat in the early 20th century as regular
      daywear, a sober one-coloured suit became known as a lounge suit. Suits
      are offered in different designs and constructions. Cut and cloth, whether
      two- or three-piece, single- or double-breasted, vary, in addition to
      various accessories. A two-piece suit has a jacket and trousers; a
      three-piece suit adds a waistcoat.[1] Hats were almost always worn
      outdoors (and sometimes indoors) with all mens clothes until the
      counterculture of the 1960s in Western culture. Informal suits have been
      traditionally worn with a fedora, a trilby, or a flat cap. Other

        </p>
    </div>
    <button onClick={handleGoBack} style={{marginLeft:"30%"}}>Go Back</button>
     

     
    </>
  );
}

export default ExploreSuit;
