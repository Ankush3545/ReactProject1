//import React from 'react'

import { useState } from "react"
import { useNavigate } from "react-router-dom"

export default function Contact() {
  const navigate=useNavigate();
  const [phonedata,setPhoneData]=useState({
    name:"",
    city:"",
    phone:"",

  })
  const [maildata,setMailData]=useState({
    mailName:"",
    mailCity:"",
    email:"",

  })
  const handleChange=(e)=>{
    setPhoneData({...phonedata,[e.target.name]:e.target.value})
    setMailData({...maildata,[e.target.name]:e.target.value})

  }
  const handleSubmitPhone=(e)=>{
    e.preventDefault();
    if(phonedata.name===""){
      alert("Name is required")

    }
    else if(phonedata.city===""){
      alert("Enter the city Name")
    }
    else if(phonedata.phone===""){
      alert("Enter the  Contact Number")

    }
    else{
      console.log(phonedata);
    setPhoneData({name:"",city:"",phone:""});
    navigate("/")

    }
    
    

  }
  const handleSubmitEmail=(e)=>{
    e.preventDefault();
    if(maildata.mailName===""){
      alert("Name is required")

    }
    else if(maildata.mailCity===""){
      alert("Enter the city Name")
    }
    else if(maildata.email===""){
      alert("Enter the  Contact Number")

    }
    else{
      console.log(maildata);
 
      setPhoneData({mailName:"",mailCity:"",email:""});
      navigate("/");
      alert("Thank You For Reaching out Our Team  will contact shortly")
    }
  }
  return (
    <> 
   <div style={{display:"flex"}}>

    <div className="contactphonediv">
     <h2 style={{textDecoration:"underline",marginTop:"-25px"}}>Contact via Phone Number</h2>

     <form style={{marginTop:"20px"}} >
      <label htmlFor="" className="contactformname">Enter Your Name</label><br></br>
      <input type="text" className="contactformlabel"
      value={phonedata.name}
      name="name"
      onChange={handleChange}></input><br></br>
      <label htmlFor="" className="contactformcity">Enter your City</label><br></br>
      <input type="text" className="contactformlabel"
      value={phonedata.city}
      name="city"
      onChange={handleChange}></input><br></br>
      <label htmlFor="" className="contactformphone">Enter Phone Number</label><br></br>
      <input type=" number" className="contactformlabel"
      value={phonedata.phone}
      name="phone"
      onChange={handleChange}></input><br></br>
      <button onClick={handleSubmitPhone}>Submit</button>
     </form>
    </div>

    <div className="contactmaildiv">
     <h2 style={{textDecoration:"underline",marginTop:"-25px"}}>Contact Via Email/Gmail ID</h2>

     <form style={{marginTop:"20px"}}>
      <label htmlFor="" className="contactformname">Enter your Name</label><br></br>
      <input type="text" className="contactformlabel"
      value={maildata.mailName}
      name="mailName"
      onChange={handleChange}></input><br></br>
      <label htmlFor="" className="contactformcity">Enter your City</label><br></br>
      <input type="text" className="contactformlabel"
      value={maildata.mailCity}
      name="mailCity"
      onChange={handleChange}></input><br></br>
      <label htmlFor="" className="contactformphone">Enter your mail ID</label><br></br>
      <input type="mail" className="contactformlabel"
      value={maildata.email}
      name="email"
      onChange={handleChange}></input><br></br>
      <button onClick={handleSubmitEmail}>Submit</button>
     </form>
    </div>
   </div>
    
   
    </>
  )
}
